This is where all your compiled CSS will go, so point your HTML to this directory
for loading your styles.


por si se resetea main esto se añadió nuevo

h1#page-title {
font-size: 18px;
padding: 0;
line-height: 0px;
margin: 0 0 10px;
}
.navbar-default {
background-color: #002759;
border-color: #002759;
}