This is where Compass will place generated images, such as sprites.

You can also add images here that you don't need Sass to know about.
